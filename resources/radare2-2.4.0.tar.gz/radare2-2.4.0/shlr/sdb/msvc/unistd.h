//fake include file to avoid error on windows compilation.
#include <io.h>
