/* befs.c - The native BeOS/Haiku file-system.  */
#define MODE_BFS 1
#define MODE_BIGENDIAN 1
#include "afs.c"
