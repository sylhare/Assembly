This is simple application which shows how to work with floating point numbers.

Build it with: `make`

More details at - [Say hello to x64 Assembly [part 8]](https://0xax.github.io/asm_8/)

[@0xAX](https://twitter.com/0xAX)
