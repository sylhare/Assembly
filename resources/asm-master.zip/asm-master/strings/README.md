This is "reverse string" with assembly for Linux x86-64.

Build it with: `make`

More details at - [Say hello to x64 Assembly [part 4]](https://0xax.github.io/asm_4/)

[@0xAX](http://twitter.com/0xAX)
