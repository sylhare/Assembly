This is "sum of 2 numbers" with assembly for Linux x86-64

Build it with: `make`

More details at - [Say hello to x64 Assembly [part 2]](https://0xax.github.io/asm_2/)

[@0xAX](http://twitter.com/0xAX)

