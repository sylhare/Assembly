This is simple application which gets two command line arguments, sums it and prints result.

Build it with: `make`

More details at - [Say hello to x64 Assembly [part 3]](https://0xax.github.io/asm_3/)

[@0xAX](http://twitter.com/0xAX)

