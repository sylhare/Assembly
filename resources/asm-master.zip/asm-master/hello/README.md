This is "Hello world" with assembly for Linux x86-64

Build it with: `make`

More details at - [Say hello to x64 Assembly [part 1]](https://0xax.github.io/asm_1/)

[@0xAX](http://twitter.com/0xAX)
